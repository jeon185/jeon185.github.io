#!/bin/bash

cd src/
python main.py --epochs 300 --nation us --target devcon