import os
import sys

import click
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torch.utils.data import DataLoader

from models import SmartSense
from utils import *

CUDA = torch.cuda.is_available()
DEVICE = torch.device('cuda' if CUDA else 'cpu')


@click.command()
@click.option('--epochs', type=int, default=300)
@click.option('--nation', type=str, default='us')
@click.option('--target', type=str, default='device')
def main(epochs, nation, target):
    """
    Main file to train and test the model.
    :param epochs: number of epochs to run.
    :param nation: language to select from ['kr', 'us', 'fr', 'sp'].
    :param target: chosen target of the model from ['device control', 'device'].
    """
    # read files
    data_path = f'../data/processed/{nation}'
    if nation == 'kr':
        import dictionary.dictionary_kr as dictionary
    elif nation == 'us':
        import dictionary.dictionary_us as dictionary
    elif nation == 'fr':
        import dictionary.dictionary_fr as dictionary
    elif nation == 'sp':
        import dictionary.dictionary_sp as dictionary
    device_control_dict = dictionary.device_control_dict
    device_dict = dictionary.device_dict
    control_dict = dictionary.control_dict
    timerange_dict = dictionary.timerange_dict
    weekday_dict = dictionary.weekday_dict
    device_corpus_path = os.path.join(data_path, 'routine_device_corpus.txt')

    # control to device control mappings
    control_devcon_map = np.zeros((len(control_dict), len(device_control_dict)))
    for con_k, con_v in control_dict.items():
        for devcon_k, devcon_v in device_control_dict.items():
            if devcon_k.endswith(con_k):
                control_devcon_map[con_v, devcon_v] = 1
    control_devcon_map = torch.tensor(control_devcon_map).to(DEVICE)

    # device control to device mappings
    devcon_device_map = np.zeros(len(device_control_dict))
    for devcon_k, devcon_v in device_control_dict.items():
        for device_k, device_v in device_dict.items():
            if devcon_k.startswith(device_k):
                devcon_device_map[devcon_v] = device_v
    devcon_device_map = torch.tensor(devcon_device_map).to(DEVICE)

    # routine knowledge transfer settings
    reg_batch_size = 100
    reg_window_size = 5
    reg_iteration = 1
    w2v_min_count = 1
    reg_num_neg = 5
    device_input_data = RoutineData(device_corpus_path, w2v_min_count)

    # trn/vld/test:7/1/2
    seqlen = 10
    trn_path = os.path.join(data_path, f'trn_instance_{seqlen}.pkl')
    vld_path = os.path.join(data_path, f'vld_instance_{seqlen}.pkl')
    test_path = os.path.join(data_path, f'test_instance_{seqlen}.pkl')
    trn_instance, vld_instance, test_instance = load_pickles(trn_path, vld_path, test_path)

    # data loaders
    trn_dataset = SequenceDataset(trn_instance)
    vld_dataset = SequenceDataset(vld_instance)
    test_dataset = SequenceDataset(test_instance)
    trn_dataloader = DataLoader(trn_dataset, batch_size=1024, shuffle=True)
    vld_dataloader = DataLoader(vld_dataset, batch_size=1024, shuffle=False)
    test_dataloader = DataLoader(test_dataset, batch_size=1024, shuffle=False)

    # model configuration
    model = SmartSense(num_device_control=len(device_control_dict),
                       num_device=len(device_dict),
                       num_timerange=len(timerange_dict),
                       num_weekday=len(weekday_dict),
                       seqlen=seqlen).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)

    best_acc = 0.
    best_report = ''
    ks = [1, 3, 5, 10]
    print(f'Epoch | TrnLoss | VldHR@{ks[0]}, VldHR@{ks[1]}, VldHR@{ks[2]}, VldHR@{ks[3]} | '
          f'TestHR@{ks[0]}, TestHR@{ks[1]}, TestHR@{ks[2]}, TestHR@{ks[3]} | '
          f'VldMAP@{ks[0]}, VldMAP@{ks[1]}, VldMAP@{ks[2]}, VldMAP@{ks[3]} | '
          f'TestMAP@{ks[0]}, TestMAP@{ks[1]}, TestMAP@{ks[2]}, TestMAP@{ks[3]}')

    for epoch in range(1, epochs+1):
        epoch_loss = 0.
        cur_vld_counts = [0, 0, 0, 0]
        cur_test_counts = [0, 0, 0, 0]
        cur_vld_aps = [0, 0, 0, 0]
        cur_test_aps = [0, 0, 0, 0]

        # Regularization (commonsense knowledge transfer)
        model.train()
        regularization(model, optimizer, device_input_data,
                       reg_iteration, reg_batch_size, reg_window_size, reg_num_neg)

        # Train the model
        model.train()
        for batch_idx, (prev, cur) in enumerate(trn_dataloader):
            prev = prev.to(DEVICE)
            cur = cur.to(DEVICE)
            cur_logits = model(prev, cur)
            cur_y = cur[:, 4] # the others
            cur_logits = cur_logits.view(-1, cur_logits.size(-1)) # SAS
            optimizer.zero_grad()
            loss = criterion(cur_logits, cur_y)
            epoch_loss += loss.item()
            loss.backward()
            optimizer.step()
        epoch_loss /= (batch_idx + 1)

        # Validate the model
        model.eval()
        for batch_idx, (prev, cur) in enumerate(vld_dataloader):
            prev = prev.to(DEVICE)
            cur = cur.to(DEVICE)
            if target == 'devcon':
                cur_y = cur[:, 4]
                cur_logits = model(prev, cur)
                cur_topks = torch.topk(cur_logits, k=max(ks), dim=1)[1]
            elif target == 'device':
                cur_y = cur[:, 2]
                cur_con = cur[:, 3]
                cur_logits = model(prev, cur)
                cur_prob = torch.softmax(cur_logits, dim=1)
                cur_logits = cur_prob + control_devcon_map[cur_con]
                cur_topks = torch.topk(cur_logits, k=max(ks), dim=1)[1]
                cur_topks = cur_topks.view(-1)
                cur_topks = devcon_device_map[cur_topks].view(cur_logits.shape[0], -1)

            for i in range(len(ks)):
                cur_counts, cur_aps = calculate_accuracies(cur_topks[:, :ks[i]], cur_y)
                cur_vld_counts[i] += cur_counts
                cur_vld_aps[i] += cur_aps

        # Test the model
        model.eval()
        for batch_idx, (prev, cur) in enumerate(test_dataloader):
            prev = prev.to(DEVICE)
            cur = cur.to(DEVICE)
            if target == 'devcon':
                cur_y = cur[:, 4]
                cur_logits = model(prev, cur)
                cur_topks = torch.topk(cur_logits, k=max(ks), dim=1)[1]
            elif target == 'device':
                cur_y = cur[:, 2]
                cur_con = cur[:, 3]
                cur_logits = model(prev, cur)
                cur_prob = torch.softmax(cur_logits, dim=1)
                cur_logits = cur_prob + control_devcon_map[cur_con]
                cur_topks = torch.topk(cur_logits, k=max(ks), dim=1)[1]
                cur_topks = cur_topks.view(-1)
                cur_topks = devcon_device_map[cur_topks].view(cur_logits.shape[0], -1)

            for i in range(len(ks)):
                cur_counts, cur_aps = calculate_accuracies(cur_topks[:, :ks[i]], cur_y)
                cur_test_counts[i] += cur_counts
                cur_test_aps[i] += cur_aps

        # Print accuracies
        cur_vld_recalls, cur_test_recalls = [], []
        cur_vld_maps, cur_test_maps = [], []
        for v, t in zip(cur_vld_counts, cur_test_counts):
            cur_vld_recalls.append(v / len(vld_dataset))
            cur_test_recalls.append(t / len(test_dataset))
        for v, t in zip(cur_vld_aps, cur_test_aps):
            cur_vld_maps.append(v / len(vld_dataset))
            cur_test_maps.append(t / len(test_dataset))

        cur_report = f'{epoch:03d} | {epoch_loss:.4f} | '\
                     f'{cur_vld_recalls[0]:.4f}, {cur_vld_recalls[1]:.4f}, '\
                     f'{cur_vld_recalls[2]:.4f}, {cur_vld_recalls[3]:.4f} | '\
                     f'{cur_test_recalls[0]:.4f}, {cur_test_recalls[1]:.4f}, '\
                     f'{cur_test_recalls[2]:.4f}, {cur_test_recalls[3]:.4f} | '\
                     f'{cur_vld_maps[0]:.4f}, {cur_vld_maps[1]:.4f}, '\
                     f'{cur_vld_maps[2]:.4f}, {cur_vld_maps[3]:.4f} | '\
                     f'{cur_test_maps[0]:.4f}, {cur_test_maps[1]:.4f}, '\
                     f'{cur_test_maps[2]:.4f}, {cur_test_maps[3]:.4f}'

        print(cur_report)

        if best_acc < cur_vld_recalls[0]:
            best_acc = cur_vld_recalls[0]
            best_report = cur_report

        if epoch % 100 == 0:
            print('===== CURRENT BEST =====')
            print(best_report)

    print('===== BEST =====')
    print(best_report)


def regularization(model, optimizer, input_data,
                   iteration, batch_size, window_size, num_neg):
    """
    Regularize device embedding vectors using routine data.
    :param model: the smartsense model.
    :param optimizer: optimizer to use.
    :param input_data: input data of the model.
    :param iteration: number of iteration to run the regularizer.
    :param batch_size: size of the batch.
    :param window_size: number of devices to look.
    :param num_neg: number of negative examples.
    """
    pair_count = input_data.evaluate_pair_count(window_size)
    batch_count = iteration * pair_count / batch_size
    for i in range(int(batch_count)):
        pos_pairs = input_data.get_batch_pairs(batch_size, window_size)
        neg_v = input_data.get_neg_v_neg_sampling(pos_pairs, num_neg)
        pos_u = [pair[0] for pair in pos_pairs]
        pos_v = [pair[1] for pair in pos_pairs]
        pos_u = Variable(torch.LongTensor(pos_u)).to(DEVICE)
        pos_v = Variable(torch.LongTensor(pos_v)).to(DEVICE)
        neg_v = Variable(torch.LongTensor(neg_v)).to(DEVICE)
        optimizer.zero_grad()
        loss = model.forward_reg(pos_u, pos_v, neg_v)
        loss.backward()
        optimizer.step()


if __name__ == "__main__":
    main()
