import pickle
from collections import deque

import numpy as np
import torch
from torch.utils.data import Dataset


def load_pickles(*args):
    """
    Load pickle files.
    :param *args": arguments from the file
    :return: data from pickle
    """
    loaded_data = []
    for arg in args:
        with open(arg, 'rb') as f:
            loaded_data.append(pickle.load(f))
    return loaded_data


class SequenceDataset(Dataset):
    """
    Storing sequential instances for log data.
    :param data: data to store    
    """
    def __init__(self, data):
        """
        Initialization
        :param data: data to store    
        """
        self.data = torch.from_numpy(data.astype(np.int64))

    def __len__(self):
        """
        :return: length of the data
        """
        return self.data.shape[0]

    def __getitem__(self, idx):
        """
        Parsing the data
        :param idx: index
        :return: previous informations and current information
        """
        prev = self.data[idx, :-1, :]
        cur = self.data[idx, -1, :]
        return prev, cur


class RoutineData(object):
    """
    Storing routine data for regularization,
    such as word map, sampling table and so on.
    """
    def __init__(self, file_name, min_count):
        """
        Initialzation
        :param file_name: file name to store
        :param min_count: minimum number to count
        """
        self.input_file_name = file_name
        self.get_words(min_count)
        self.word_pair_catch = deque()
        self.init_sample_table()
        print('Word Count: %d' % len(self.word_frequency))
        print('Sentence Length: %d' % (self.sentence_length))

    def get_words(self, min_count):
        """
        Compute frequencies of items.
        :param min_count: minimum number of count
        """
        self.input_file = open(self.input_file_name)
        self.sentence_length = 0
        self.sentence_count = 0
        word_frequency = dict()
        for line in self.input_file:
            self.sentence_count += 1
            line = line.strip().split(' ')
            self.sentence_length += len(line)
            for w in line:
                try:
                    word_frequency[int(w)] += 1
                except:
                    word_frequency[int(w)] = 1
        self.word_frequency = dict()
        for w, c in word_frequency.items():
            if c < min_count:
                self.sentence_length -= c
                continue
            self.word_frequency[w] = c

    def init_sample_table(self):
        """
        Construct a sample table.
        """
        self.sample_table = []
        sample_table_size = 1e8
        pow_frequency = np.array(list(self.word_frequency.values()))**0.75
        words_pow = sum(pow_frequency)
        ratio = pow_frequency / words_pow
        count = np.round(ratio * sample_table_size)
        for wid, c in enumerate(count):
            self.sample_table += [wid] * int(c)
        self.sample_table = np.array(self.sample_table)

    def get_batch_pairs(self, batch_size, window_size):
        """
        Get positive pairs for batch training.
        :param batch_size: size of the abtch
        :param window_size: number of items to look
        :return: batch pairs
        """
        while len(self.word_pair_catch) < batch_size:
            sentence = self.input_file.readline()
            if sentence is None or sentence == '':
                self.input_file = open(self.input_file_name)
                sentence = self.input_file.readline()
            word_ids = []
            for w in sentence.strip().split(' '):
                try:
                    word_ids.append(int(w))
                except:
                    continue
            for i, u in enumerate(word_ids):
                for j, v in enumerate(
                        word_ids[max(i - window_size, 0):i + window_size]):
                    if i == j:
                        continue
                    self.word_pair_catch.append((u, v))
        batch_pairs = []
        for _ in range(batch_size):
            batch_pairs.append(self.word_pair_catch.popleft())
        return batch_pairs

    def get_neg_v_neg_sampling(self, pos_word_pair, count):
        """
        Get negative samples.
        :param pos_word_pair: positive pairs of words
        :param count: count
        :return: negative examples
        """
        neg_v = np.random.choice(
            self.sample_table, size=(len(pos_word_pair), count)).tolist()
        return neg_v

    def evaluate_pair_count(self, window_size):
        """
        Evaluate counts of pairs.
        :param window_size: number of items to look
        """
        return self.sentence_length * (2 * window_size - 1) - \
               (self.sentence_count - 1) * (1 + window_size) * window_size


def calculate_accuracies(topk, y):
    """
    Calculate accuracies in terms of Recall and mAP.
    :param topk: number of k from top
    :param y: output from the model
    :return: recall and mAP
    """
    y = y.unsqueeze(1).repeat(1, topk.shape[1])
    table = (topk == y).float()
    table_sum = torch.clamp(table.sum(dim=1), max=1, min=0).sum()
    recall_sum = float(table_sum.item())
    idxs = torch.nonzero(table, as_tuple=True)[1]
    map_sum = float((1/(idxs + 1).float()).sum().item())
    return recall_sum, map_sum
