import math

import torch
import torch.nn as nn
import torch.nn.functional as F

CUDA = torch.cuda.is_available()
DEVICE = torch.device('cuda' if CUDA else 'cpu')


class SmartSense(nn.Module):
    """
    Our proposed model: SmartSense.
    """
    def __init__(self,
                 num_device_control,
                 num_device,
                 num_timerange,
                 num_weekday,
                 seqlen,
                 emb_dim=50):
        """
        Initialization of the model.
        :param num_device_control: number of total device controls.
        :param num_device: number of total device.
        :param num_timerange: number of ranges of the time.
        :param num_weekday: number of weekdays (7).
        :param seqlen: maximum sequence length to look.
        :param emb_dim: dimension size of the encoder.
        """

        super(SmartSense, self).__init__()
        self.weekday_emb = nn.Embedding(num_weekday, emb_dim)
        self.timerange_emb = nn.Embedding(num_timerange, emb_dim)
        self.device_emb = nn.Embedding(num_device, emb_dim)
        self.devcon_emb = nn.Embedding(num_device_control, emb_dim)
        self.out_devcon_emb = nn.Embedding(num_device_control, emb_dim)
        self.position_emb = nn.Embedding(seqlen-1, emb_dim)
        self.emb_dim = emb_dim
        self.seqlen = seqlen

        # multi-layers transformer blocks, deep network
        hidden = emb_dim
        heads = 2
        dropout = 0.1
        n_layers = 2
        self.dropout = nn.Dropout(p=dropout)
        self.action_transformers = nn.ModuleList(
            [TransformerBlock(hidden, heads, hidden * 4, dropout) for _ in range(n_layers)])
        self.sequence_transformers = nn.ModuleList(
            [TransformerBlock(hidden, heads, hidden * 4, dropout) for _ in range(n_layers)])
        self.la1 = LinearAttn(output_dim=emb_dim, query_dim=emb_dim)
        self.la2 = LinearAttn(output_dim=emb_dim, query_dim=2*emb_dim)
        self.q = nn.Embedding(1, emb_dim)

    def forward(self, prev_x, cur_x):
        """
        For each instance, the model returns logits over devices or device controls.
        :param prev_x: sequential previous data.
        :param cur_x: current data.
        :return: logits over devices or device controls.
        """
        prev_weekday_emb = self.weekday_emb(prev_x[:, :, 0])
        prev_timerange_emb = self.timerange_emb(prev_x[:, :, 1])
        prev_device_emb = self.device_emb(prev_x[:, :, 2])
        prev_devcon_emb = self.devcon_emb(prev_x[:, :, 4])

        prev_weekday_emb = prev_weekday_emb.unsqueeze(2)
        prev_timerange_emb = prev_timerange_emb.unsqueeze(2)
        prev_device_emb = prev_device_emb.unsqueeze(2)
        prev_devcon_emb = prev_devcon_emb.unsqueeze(2)
        concated = torch.cat((prev_weekday_emb, prev_timerange_emb, prev_device_emb, prev_devcon_emb), dim=2)
        x = concated.view(-1, concated.size(2), concated.size(3))

        # Encode actions
        for transformer in self.action_transformers:
            x = transformer.forward(x)
        concated = x
        prev_x = self.la1(concated, self.q.weight.repeat(concated.size(0), 1))
        prev_x = prev_x.view(prev_timerange_emb.size(0), -1, concated.size(2))

        # Encode sequences
        pe = self.position_emb.weight.unsqueeze(0).repeat(prev_x.size(0), 1, 1)
        x = prev_x + pe
        x = self.dropout(x)
        for transformer in self.sequence_transformers:
            x = transformer.forward(x)
        out = x
        cur_weekday_emb = self.weekday_emb(cur_x[:, 0])
        cur_timerange_emb = self.timerange_emb(cur_x[:, 1])
        seq_query = torch.cat((cur_weekday_emb, cur_timerange_emb), dim=1)
        out = self.la2(out, seq_query)
        cur_out = torch.matmul(out, self.devcon_emb.weight.T)

        return cur_out

    def forward_reg(self, pos_u, pos_v, neg_v):
        """
        Compute regularization loss.
        :param pos_u: target device.
        :param pose_v: positive example of target device (which means devices that close to the pos_u).
        :param neg_v: negative eaxmple of target device (which means devices that far from the pos_u).
        :return: return the regularization loss
        """
        emb_u = self.device_emb(pos_u)
        emb_v = self.device_emb(pos_v)
        score = torch.mul(emb_u, emb_v).squeeze()
        score = torch.sum(score, dim=1)
        score = F.logsigmoid(score)
        neg_emb_v = self.device_emb(neg_v)
        neg_score = torch.bmm(neg_emb_v, emb_u.unsqueeze(2)).squeeze()
        neg_score = F.logsigmoid(-1 * neg_score)
        return -1 * (torch.sum(score) + torch.sum(neg_score))


def init_weights(m):
    """
    Initialize parameters
    :param m: target layer to initialize
    """
    if type(m) == nn.Linear:
        nn.init.xavier_uniform_(m.weight)


class LinearAttn(nn.Module):
    """
    Linear attention class
    
    """
    def __init__(self, output_dim, query_dim):
        """
        Initialization of the class
        :param output_dim: dimension of the output
        :param key_dim: query vector dimension
        """
        super(LinearAttn, self).__init__()

        self.W = nn.Linear(output_dim, query_dim, bias=True)
        self.q = nn.Linear(query_dim, 1, bias=False)
        self.tanh = nn.Tanh()

        self.W.apply(init_weights)
        self.q.apply(init_weights)

    def forward(self, inputs, q):
        """
        Summarize the input vectors into a vector using the query q.
        :param inputs: input x
        :param q: query q
        :return: queried score
        """
        q = q.unsqueeze(1).repeat(1, inputs.size(1), 1)
        attn = self.tanh(self.W(inputs))
        score = torch.mul(q, attn).sum(2)
        score = F.softmax(score, dim=1).unsqueeze(2).repeat(1, 1, inputs.size(2))
        output = torch.mul(inputs, score).sum(1)
        return output


class Attention(nn.Module):
    """
    Compute a scaled dot product attention
    """

    def forward(self, query, key, value, dropout=None):
        """
        calculate the self-attention
        :param query: query matrix
        :param key: key matrix
        :param value: value matrix
        :return: calculated matrix and probability of attention 
        """
        scores = torch.matmul(query, key.transpose(-2, -1)) \
                 / math.sqrt(query.size(-1))

        p_attn = F.softmax(scores, dim=-1)

        if dropout is not None:
            p_attn = dropout(p_attn)

        return torch.matmul(p_attn, value), p_attn


class MultiHeadedAttention(nn.Module):
    """
    Multi-head attention module.
    """
    def __init__(self, h, d_model, dropout=0.1):
        """
        Initialization fo the class
        :param h: hidden dimension size
        :param d_model: model dimension size
        """
        super().__init__()
        assert d_model % h == 0

        # We assume d_v always equals d_k
        self.d_k = d_model // h
        self.h = h

        self.linear_layers = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(3)])
        self.output_linear = nn.Linear(d_model, d_model)
        self.attention = Attention()

        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value):
        batch_size = query.size(0)

        # 1) Do all the linear projections in batch from d_model => h x d_k
        query, key, value = [l(x).view(batch_size, -1, self.h, self.d_k).transpose(1, 2)
                             for l, x in zip(self.linear_layers, (query, key, value))]

        # 2) Apply attention on all the projected vectors in batch.
        x, attn = self.attention(query, key, value, dropout=self.dropout)

        # 3) "Concat" using a view and apply a final linear.
        x = x.transpose(1, 2).contiguous().view(batch_size, -1, self.h * self.d_k)

        return self.output_linear(x)


class LayerNorm(nn.Module):
    """
    Layer normalization module.
    """
    def __init__(self, features, eps=1e-6):
        """
        initialization of the class
        :param features: number of features for the normalizer
        :param eps: epsilon to block infinite
        """
        super(LayerNorm, self).__init__()
        self.a_2 = nn.Parameter(torch.ones(features))
        self.b_2 = nn.Parameter(torch.zeros(features))
        self.eps = eps

    def forward(self, x):
        """
        normalize input
        :param x: input
        :return: normalized input
        """
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a_2 * (x - mean) / (std + self.eps) + self.b_2


class SublayerConnection(nn.Module):
    """
    A residual connection followed by a layer norm.
    """
    def __init__(self, size, dropout):
        """
        Initialization of the class
        :param size: size of the normalizer
        :param dropout: drop out rate
        """
        super(SublayerConnection, self).__init__()
        self.norm = LayerNorm(size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, sublayer):
        """
        Apply residual connection to any sublayer with the same size.
        :param x: input
        :param sublayer: sublayer to connect
        """
        return x + self.dropout(sublayer(self.norm(x)))


class PositionwiseFeedForward(nn.Module):
    """
    Position-wise feedforward module.
    """
    def __init__(self, d_model, d_ff, dropout=0.1):
        """
        Initialization of the class
        :param d_model: dimension size of the w1
        :param d_ff: dimension size of the w2
        """
        super(PositionwiseFeedForward, self).__init__()
        self.w_1 = nn.Linear(d_model, d_ff)
        self.w_2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.ReLU()

    def forward(self, x):
        return self.w_2(self.dropout(self.activation(self.w_1(x))))


class TransformerBlock(nn.Module):
    """
    Transformer encoder.
    Transformer = MultiHead_Attention + Feed_Forward with sublayer connection
    """
    def __init__(self, hidden, attn_heads, feed_forward_hidden, dropout):
        super().__init__()
        """
        Initialization of the class
        :param hidden: dimension size of the hidden layer
        :param attn_heads: number of the heads in multi attention
        :param feed_forward_hidden: dimension size of feed forward network
        :param dropout: drop out rate
        """
        self.attention = MultiHeadedAttention(h=attn_heads, d_model=hidden, dropout=dropout)
        self.feed_forward = PositionwiseFeedForward(d_model=hidden, d_ff=feed_forward_hidden, dropout=dropout)
        self.input_sublayer = SublayerConnection(size=hidden, dropout=dropout)
        self.output_sublayer = SublayerConnection(size=hidden, dropout=dropout)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x):
        x = self.input_sublayer(x, lambda _x: self.attention.forward(_x, _x, _x))
        x = self.output_sublayer(x, self.feed_forward)
        return self.dropout(x)


